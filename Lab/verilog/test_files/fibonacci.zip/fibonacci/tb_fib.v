module tb_fib;

  reg clk;
  reg reset;
  reg start;
  reg [7:0] K;

  wire [7:0] O;

  fibonacci dut (
      .clk(clk),
      .reset(reset),
      .start(start),
      .K(K),
      .O(O)
  );

  always #5 clk = ~clk;

  initial begin
    clk = 0;
    reset = 1;
    start = 0;
    K = 0;

    // Reset
    #10;
    reset = 0;

    // Calculate F(10)
    K = 10;
    start = 1;

    #10;
    start = 0;

    // Wait for computation
    #200;

    $display("F(%d) = %d", K, O);

    $finish;
  end

endmodule
